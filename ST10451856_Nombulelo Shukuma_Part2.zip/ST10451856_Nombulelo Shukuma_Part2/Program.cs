﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Threading;

namespace ST10451856_NombuleloShukuma_Part2
{
    internal class Program
    {
        // Dictionary of direct responses to keywords
        static Dictionary<string, string> keywordResponses = new Dictionary<string, string>()
        {
                {"hack", "Hacking is the practice of taking advantage of holes in computer networks or systems to obtain data without authorization or interfere with operations. " +
                "If you're concerned about hacking or believe you've been hacked, I can help you understand how to stay safe and protect your devices." },
                {"antivirus", "Antivirus software helps protect your computer or phone from viruses, malware, and other online threats." +
                " Many antivirus tools also block dangerous websites and phishing attempts. Keeping your antivirus up to date is one of the easiest ways to stay safe online."},
                {"password", "The secret to protecting your accounts and private information is your password. Combine capital and lowercase characters, digits, and symbols to create a strong password." +
                "Don't use the same password on several websites. To safely keep track of everything, think about utilizing a password manager." },
                {"online safety", "Online safety means protecting your personal information and avoiding scams or cyber threats. Use strong passwords, avoid suspicious links, and keep your software updated" },
                {"Pop-ups", "Pop-ups can sometimes be used for scams or to trick you into downloading malware. Most browsers have a setting to block them. You can also install an ad blocker for extra protection." },
                {"downloads", "Make sure to always download files or apps from official websites or trusted app stores.  Avoid clicking 'download' buttons on random pop-ups or shady websites." }

        };

        //a list of predefined responses per category for follow-up queries
        static List<string> hackResponses = new List<string>()
        {
            "If you think you've been hacked, change your passwords immediately, enable two-factor authentication, and run a full antivirus scan on your device. Let me know if you need help securing your accounts.",
            "The term 'hack' usually refers to gaining unauthorized access to systems or data. While some hacking is illegal and harmful, ethical hackers use their skills to find and fix security issues",
            "If you think you've been hacked, change your passwords immediately, enable two-factor authentication, and run a full antivirus scan on your device. Let me know if you need help securing your accounts."
        };

        static List<string> antivirusResponses = new List<string>()
        {
            "Having antivirus software is a smart way to protect your devices — especially if you browse the internet, download files, or use email regularly.",
            "Antivirus software helps protect your computer or phone from harmful programs like viruses, malware, and spyware. It scans and removes threats to keep your data safe.",
            "Make sure your antivirus is always updated. New threats appear every day, and updates keep your protection current."
        };

        static List<string> passwordResponses = new List<string>()
        {
            "Changing your password regularly reduces the risk of someone gaining unauthorized access to your account — especially if a site you use was hacked or your credentials were leaked.",
            "A strong password should be at least 12 characters long and include a mix of uppercase letters, lowercase letters, numbers, and symbols. Avoid using personal information like your name or birthdate.",
            "It's not safe to reuse passwords. If one site gets breached, hackers can try the same password on other accounts. Use different passwords for each service."
        };

        static List<string> onlineSafetyResponses = new List<string>()
        {
            "Use strong passwords, don’t share personal info on suspicious websites, be careful what you click on, and keep your devices updated. These small steps go a long way",
            "Avoid sharing private info like your address or phone number. Set your profiles to private, and don’t accept friend requests from people you don’t know.",
            "Online safety means protecting your personal information and staying safe while using the internet — whether you're browsing, shopping, or using social media."
        };

        static List<string> popupsResponses = new List<string>()
        {
            "Pop-ups are small windows or messages that suddenly appear while you're browsing the internet. Some are harmless (like login forms), but others can be annoying or even dangerous.",
            "Most web browsers let you block pop-ups. Go into your browser's settings and turn on the pop-up blocker. You can also use ad blockers for extra protection.",
            "Some pop-ups are used for scams, fake virus alerts, or tricking you into downloading malware. If a pop-up looks suspicious, don't click it — just close the tab or window."
        };

        static List<string> downloadsResponses = new List<string>()
        {
            "A download is when you transfer a file from the internet to your device — like apps, documents, music, or videos. It’s important to only download from trusted sources to stay safe.",
            "Some downloads are safe, but others may contain viruses or malware. Always download files from official websites or trusted app stores, and avoid clicking download buttons on pop-ups or shady websites.",
            "If you think a download was unsafe, don’t open it. Delete the file, and run a full antivirus scan to check for threats."
        };


        // Keywords to detect sentiment
        static List<string> sentimentKeywords = new List<string> { "worried", "happy", "uneasy", "unsure", "excited", "frustrated" };

        // Sentiment-based responses
        static Dictionary<string, string> sentimentResponses = new Dictionary<string, string>
        {
                       {"worried", "It's completely understandable to feel that way. Many people feel the same. Let me share some tips to help you stay safe online."},
            {"uneasy", "Cybersecurity can be confusing, but I'm here to help break it down for you. Let's take it one step at a time."},
            {"unsure", "No worries — it's okay to be unsure. Let's look at what you can do to feel more confident about cybersecurity."},
            {"excited", "That's awesome! Being excited about learning cybersecurity will take you far. What would you like to know more about?"},
            {"happy", "I'm glad to hear that! Keeping a positive attitude helps make the learning experience smoother."},
            {"frustrated", "I understand how frustrating this can be. Let's work through your concerns together."}
        };


        static string currentTopic = "";
        static string userName = ""; // It is used to track user's name
        static string userInterest = "";
        static Random rand = new Random();

        static void Main(string[] args)
        {
            // Display ASCII logo
            Console.WriteLine(@"
.......................WWWW.......................
......................W0xk0W......................
............WWWWWWWWWWNOooONWWWWWWWWWW............
........WNKOkkkkkkkkkkkdoodkkkkkkkkkkkOKNW........
.......W0xdk00000000000000000000000000kdxKW.......
......WKddKW..........................WKddKW......
WXXW..W0okN............................Xko0W..WXXW
XxxX..W0okN............................Nko0W.WXxxX
KdxX..W0okN....NKO0XW........WX0OKN....Nko0W.WXxdK
KdxX..W0okN...WKdlokN........NkoldKW...Nko0W.WXxdK
KdxXW.W0okN....NKO0XW........WX0OKN....Nko0W.WXxdK
XxxX..W0okN............................Nko0W.WXxxX
WXXW..W0okXW..........................WXko0W..WXXW
......W0odkOOOOOOOOOOOOOOOOOOOOOOOOOOOOkdo0W......
......W0odkOOOOOOOOOOOOOOOOOOOOOOOOOOOOkdo0W......
......W0okNW..........................WNko0W......
......W0dxX............................XxdKW......
.......NkdkKXNNNNNNNWW......WNNNNNNNNXKkdON.......
........NKkxxxxxxxxxx0W....W0xxxxxxxxxxkKN........
..........WNNNXNNNXKxdONWWNOdxKXNNNXXNNW..........
....................NOdxOOxdON....................
.....................W0dood0W.....................
......................WXKKXW......................

.....................Charlamos....................
");

            // Attempt to play welcome audio
            try
            {
                string audioPath = @"C:\\Users\\RC_Student_lab\\source\\repos\\ST10451856_NombuleloShukuma_Part1\\Welcoming message.wav";

                if (File.Exists(audioPath))
                {
                    SoundPlayer player = new SoundPlayer(audioPath);
                    player.Load();
                    player.Play();
                    Console.WriteLine("Finished playing the welcoming message.");
                }
                else
                {
                    Console.WriteLine("Audio file is not found " + audioPath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing sound: " + ex.Message);
            }

            // Wait for Enter to clear logo
            Console.WriteLine("You can press Enter after viewing the logo to continue with the program...");
            Console.ReadLine();
            Console.Clear();

            // Ask for name
            Console.WriteLine("Hello. Please enter your name.");
            userName = Console.ReadLine(); // FIX: avoid shadowing the global variable
            Console.WriteLine($"Welcome to Cyber Security Bot {userName}, how may I be of help?");

            while (true)
            {
                string response = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(response))
                {
                    Console.WriteLine("Please enter something so I can assist you.");
                    continue;
                }

                string loweredResponse = response.ToLowerInvariant();

                if (loweredResponse == "bye")
                {
                    PauseTypingEffect();
                    Console.WriteLine("Goodbye, it was nice chatting with you. Have a lovely day!");
                    break;
                }

                if (loweredResponse == "hello")
                {
                    PauseTypingEffect();
                    Console.WriteLine($"Hello, {userName}! How can I assist you today?");
                    currentTopic = "";
                    continue;
                }

                if (loweredResponse == "how are you?")
                {
                    PauseTypingEffect();
                    Console.WriteLine($"I'm well, thanks for asking {userName}. How may I assist?");
                    continue;
                }

                if (loweredResponse == "what is your purpose?")
                {
                    PauseTypingEffect();
                    Console.WriteLine($"I'm here to provide cybersecurity advice and safety tips, {userName}.");
                    continue;
                }

                if (loweredResponse == "what can i ask you about?")
                {
                    PauseTypingEffect();
                    Console.WriteLine("You can ask me about topics like hacking, antivirus, passwords, online safety, pop-ups, phishing, and downloads.");
                    continue;
                }

                if (response.StartsWith("I'm interested in", StringComparison.OrdinalIgnoreCase))
                {
                    string interest = response.Substring("I'm interested in".Length).TrimEnd('.', '!', ' ').Trim();
                    if (!string.IsNullOrEmpty(interest))
                    {
                        userInterest = interest;
                        PauseTypingEffect();
                        Console.WriteLine($"Great! I’ll remember that you’re interested in {userInterest}. It’s a crucial part of staying safe online.");
                    }
                    else
                    {
                        Console.WriteLine("Could you tell me more about what you're interested in?");
                    }
                    continue;
                }

                // Provide more detail about the current topic
                if (loweredResponse.Contains("more"))
                {
                    PauseTypingEffect();
                    switch (currentTopic)
                    {
                        case "hack":
                            Console.WriteLine(hackResponses[rand.Next(hackResponses.Count)]);
                            break;
                        case "password":
                            Console.WriteLine(passwordResponses[rand.Next(passwordResponses.Count)]);
                            break;
                        case "antivirus":
                            Console.WriteLine(antivirusResponses[rand.Next(antivirusResponses.Count)]);
                            break;
                        case "online safety":
                            Console.WriteLine(onlineSafetyResponses[rand.Next(onlineSafetyResponses.Count)]);
                            break;
                        case "download":
                            Console.WriteLine(downloadsResponses[rand.Next(downloadsResponses.Count)]);
                            break;
                        case "pop-up":
                            Console.WriteLine(popupsResponses[rand.Next(popupsResponses.Count)]);
                            break;
                        default:
                            Console.WriteLine("Which topic would you like more details on?");
                            break;
                    }
                    continue;
                }

                // Match sentiment and respond accordingly
                foreach (var keyword in sentimentResponses.Keys)
                {
                    if (loweredResponse.Contains(keyword))
                    {
                        PauseTypingEffect();
                        Console.WriteLine(sentimentResponses[keyword]);
                        currentTopic = "";
                        goto Next;
                    }
                }

                // Check for topic keywords and respond
                if (loweredResponse.Contains("hack"))
                {
                    PauseTypingEffect();
                    Console.WriteLine(hackResponses[rand.Next(hackResponses.Count)]);
                    currentTopic = "hack";
                    continue;
                }
                if (loweredResponse.Contains("password"))
                {
                    PauseTypingEffect();
                    Console.WriteLine(passwordResponses[rand.Next(passwordResponses.Count)]);
                    currentTopic = "password";
                    continue;
                }
                if (loweredResponse.Contains("antivirus"))
                {
                    PauseTypingEffect();
                    Console.WriteLine(antivirusResponses[rand.Next(antivirusResponses.Count)]);
                    currentTopic = "antivirus";
                    continue;
                }
                if (loweredResponse.Contains("online safety"))
                {
                    PauseTypingEffect();
                    Console.WriteLine(onlineSafetyResponses[rand.Next(onlineSafetyResponses.Count)]);
                    currentTopic = "online safety";
                    continue;
                }
                if (loweredResponse.Contains("download"))
                {
                    PauseTypingEffect();
                    Console.WriteLine(downloadsResponses[rand.Next(downloadsResponses.Count)]);
                    currentTopic = "download";
                    continue;
                }
                if (loweredResponse.Contains("pop-up") || loweredResponse.Contains("popup") || loweredResponse.Contains("popups"))
                {
                    PauseTypingEffect();
                    Console.WriteLine(popupsResponses[rand.Next(popupsResponses.Count)]);
                    currentTopic = "pop-up";
                    continue;
                }

                // General keyword match
                bool matched = false;
                foreach (var keyword in keywordResponses.Keys)
                {
                    if (loweredResponse.Contains(keyword.ToLower()))
                    {
                        PauseTypingEffect();
                        Console.WriteLine(keywordResponses[keyword]);
                        currentTopic = keyword.ToLower();
                        matched = true;
                        break;
                    }
                }

                if (!matched)
                {
                    PauseTypingEffect();
                    Console.WriteLine("Charlamos: I'm sorry, I didn't understand that. Could you try rephrasing?");
                }

            Next:; // Skip to next loop iteration after sentiment
            }
        }

        // Simulate typing effect to enhance realism
        static void PauseTypingEffect()
        {
            Console.Write("Charlamos is typing");
            for (int i = 0; i < 3; i++)
            {
                Thread.Sleep(500);
                Console.Write(".");
            }
            Console.WriteLine();
        }
    }
}